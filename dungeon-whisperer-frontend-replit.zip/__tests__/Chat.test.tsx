// Chat test placeholder
